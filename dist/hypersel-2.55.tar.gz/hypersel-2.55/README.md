Wrapper around some crawling tools
