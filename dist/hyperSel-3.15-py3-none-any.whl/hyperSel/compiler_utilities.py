# PIPE PYINSTALLER
# ON USE OF CUSTOM COMMAND WE ADD to the code somewhere something that knows the date of inception
# inside the code we added, we will have a thread that checks the current time vs that date of inception
# if we do not have a key, which we will specify with a flag, the code will stop working if we are after N days past alloted time