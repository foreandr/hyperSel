def test_func(msg):
    print(msg)