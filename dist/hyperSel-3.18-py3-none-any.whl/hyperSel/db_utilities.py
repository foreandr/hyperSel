def insert_data(data):
    pass